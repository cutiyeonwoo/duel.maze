# Duel Maze

1인 또는 같은 컴퓨터 2인 대전으로 즐기는 8단계 미로 게임입니다.

## 실행

`index.html`을 브라우저에서 열면 바로 실행됩니다. 배포용 빌드 과정이 없는 정적 웹앱입니다.

## 조작

- 1P: `W A S D`
- 2P: 방향키
- 힌트: 화면의 힌트 버튼

## Firebase 설정

`.env.example`을 복사해 `.env.local`을 만들고 Firebase 웹앱 설정값을 입력하세요.

```bash
cp .env.example .env.local
```

Firebase는 현재 점수/클리어 기록 저장을 위한 준비 코드가 포함되어 있습니다. 설정값이 없으면 앱은 로컬 게임으로 정상 실행됩니다. 정적 배포에서는 `src/firebase.js`의 `firebaseConfig` 값을 Firebase Console의 웹앱 설정값으로 채우면 됩니다.

## Vercel 배포

GitHub에 업로드한 뒤 Vercel에서 저장소를 연결하세요.

- Framework Preset: `Other`
- Build Command: 비워두기
- Output Directory: `.`

Firebase 환경변수를 쓰는 경우 Vercel Project Settings의 Environment Variables에 `.env.example`의 값을 등록하세요.
